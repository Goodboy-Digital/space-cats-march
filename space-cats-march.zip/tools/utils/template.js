const assets = {{ASSETS}};

export default assets;
