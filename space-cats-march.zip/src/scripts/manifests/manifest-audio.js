const assets = [
	{
	"id":"dream1",
	"url":"assets/audio\\dream1.mp3"
	},
	{
	"id":"dream2",
	"url":"assets/audio\\dream2.mp3"
	}
];

export default assets;
