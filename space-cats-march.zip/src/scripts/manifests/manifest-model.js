const assets = [
	{
	"id":"board",
	"url":"assets/model\\board.obj",
	"type":"binary"
	},
	{
	"id":"board",
	"url":"assets/model\\test\\board.obj",
	"type":"binary"
	}
];

export default assets;
