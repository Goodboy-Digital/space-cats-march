export default class AbstractSoundManager {
    constructor() {
    }
    getFileName(path) {
       
    }
    load(list) {
        
    }

    fadeIn(id, time = 1000) {
        
    }

    fadeOut(id, time = 1000) {
    }

    mute() {
    }

    unmute() {
    }

    toggleMute() {
    }
}