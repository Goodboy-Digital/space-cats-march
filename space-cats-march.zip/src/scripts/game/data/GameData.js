export default class GameData
{
    constructor()
    {

        this.catsData = [];

        this.trophyData = {
            collected: 0,
            collectedMultiplier: 0,
            maxCollectedMultiplier: 100,
            multplierPerCollected: 0.01,
            limitToMultiply: 1750,
        }

        // this.catsAnimations.push(
        // {
        // }
        this.totalCatsAllowed = 1;
        this.catsAllowed = [true, false, false, false];
        this.maxLife = 2;
        this.maxPoints = 0;

        this.resetCatData();
    }
    resetCatData()
    {
    	this.catsData = [];
        this.catsData.push(
        {
            catID: 0,
            collected: 0,
            active: true,
            pointsMultiplier: 1,
            collectedMultiplier: 0,
            maxCollectedMultiplier: 10,
            limitCatsToMultiply: 1500,
            catSrc: 'cat_orange_',
            catThumb: 'results_orange_cat',
            // animationList: CAT_LIST[0],
            catName: 'pancakes',
            require: null
        })

        this.catsData.push(
        {
            catID: 1,
            collected: 0,
            active: false,
            pointsMultiplier: 2,
            collectedMultiplier: 0,
            maxCollectedMultiplier: 15,
            limitCatsToMultiply: 1500,
            catSrc: 'cat_pink_',
            catThumb: 'results_pink_cat',
            // animationList: CAT_LIST[1],
            catName: 'mr. potatoes',
            require: 500
        })

        this.catsData.push(
        {
            catID: 2,
            collected: 0,
            active: false,
            pointsMultiplier: 4,
            collectedMultiplier: 0,
            maxCollectedMultiplier: 20,
            limitCatsToMultiply: 1500,
            catSrc: 'cat_turquoise_',
            catThumb: 'results_turquoise_cat',
            // animationList: CAT_LIST[2],
            catName: 'lucifurr',
            require: 5000
        })

        this.catsData.push(
        {
            catID: 3,
            collected: 0,
            active: false,
            pointsMultiplier: 8,
            collectedMultiplier: 0,
            maxCollectedMultiplier: 30,
            limitCatsToMultiply: 1500,
            catSrc: 'cat_yellow_',
            catThumb: 'results_yellow_cat',
            // animationList: CAT_LIST[3],
            catName: 'fluffy',
            require: 500000
        })
    }
    loadData(data)
    {
        this.trophyData = data.trophy;
        this.maxPoints = data.highscore;
        for (var name in data)
        {
            let n = name.indexOf("cat");
            if (n >= 0)
            {
                console.log(parseInt(name.substring(3)));
                console.log(data[name]);
                let id = parseInt(name.substring(3))
                this.catsData[id] = data[name];
            }
        }
    }
    getNumberTrophyToSend(){
    	let trophys = 0;
    	let catsAcc = 0;
    	for (var i = 0; i < this.catsData.length; i++)
        {
        	catsAcc += this.catsData[i].collected;
    	}

    	trophys = Math.ceil(catsAcc * 0.1) + 2
    	trophys += trophys * this.trophyData.multplierPerCollected

    	return Math.floor(trophys);
    }
    sendCatsToEarth()
    {
    	this.updateTrophy(this.getNumberTrophyToSend());
    	this.resetCatData();
    }
    getObjectData()
    {
        let obj = {
            trophy: this.trophyData,
            highscore: this.maxPoints,
        }
        for (var i = 0; i < this.catsData.length; i++)
        {
            obj['cat' + this.catsData[i].catID] = this.catsData[i];
        }

        return obj
    }
    updateTrophy(collected)
    {
        this.trophyData.collected += collected
        let mult = this.trophyData.collected * this.trophyData.multplierPerCollected// this.trophyData.maxCollectedMultiplier * this.trophyData.maxCollectedMultiplier;
        this.trophyData.collectedMultiplier = mult //* 0.01;

        console.log(this.trophyData);
        STORAGE.storeObject('game-data', this.getObjectData());
    }
    updateCatsAllowed(points)
    {
        if (points > this.maxPoints)
        {
            this.maxPoints = points;
        }
        this.totalCatsAllowed = 1;
        let temp = [true]
        let hasNew = false;
        for (var i = 1; i < this.catsData.length; i++)
        {
            let require = this.catsData[i].require;
            // let prevCat = this.catsData[require.catID]
            // console.log('this car require ', require.quant, points);
            if (require <= points) //prevCat.collected)
            {
                this.catsData[i].active = true;
                if (!this.catsAllowed[i])
                {
                    hasNew = i;
                }
                temp.push(true);
                this.totalCatsAllowed++;
            }
            else
            {
                temp.push(false);
            }
        }
        this.catsAllowed = temp;
        STORAGE.storeObject('game-data', this.getObjectData());
        return hasNew;
    }
    startNewRound(){
    	this.totalCatsAllowed = 0;
    	for (var i = 0; i < this.catsData.length; i++) {
    		if(this.catsData[i].active){
    			this.totalCatsAllowed ++
    		}
    	}
    	console.log('cats', this.totalCatsAllowed);
    }
    addCats(list)
    {
        for (var i = 0; i < list.length; i++)
        {
            this.catsData[i].collected += list[i];

            let mult = this.catsData[i].collected / this.catsData[i].limitCatsToMultiply * this.catsData[i].maxCollectedMultiplier;
            this.catsData[i].collectedMultiplier = mult;

        }
    }
    getAllowedCatsData()
    {
        return this.catsData[Math.floor(Math.random() * this.totalCatsAllowed)]
    }
}