import * as PIXI from 'pixi.js';
import ScreenManager from '../../screenManager/ScreenManager';
import TopMenu from './topMenu/TopMenu'
import StartPopUp from './popup/StartPopUp'
import GameOverPopUp from './popup/GameOverPopUp'
import config from '../../config';
export default class SpaceCatsScreenManager extends ScreenManager
{
    constructor()
    {
        super();
        this.backgroundContainer = new PIXI.Container();
        this.addChild(this.backgroundContainer);
        this.setChildIndex(this.backgroundContainer, 0);

        let bgColor = new PIXI.Graphics().beginFill(0x12073f).drawRect(0,0,config.width, config.height);
        this.backgroundContainer.addChild(bgColor)

        let tiled = new PIXI.extras.TilingSprite(PIXI.Texture.from('pattern'), 132, 200);
        this.backgroundContainer.addChild(tiled)
        tiled.width = config.width;
        tiled.height = config.height;
        tiled.alpha = 0.05
        tiled.tileScale.set(0.5)

        // goodboy.height = config.height;
        let bigBlur = new PIXI.Sprite(PIXI.Texture.from('bigblur'));
        this.backgroundContainer.addChild(bigBlur)
        bigBlur.width = config.width;
        bigBlur.height = config.height;
        bigBlur.alpha = 0.2

        let vignette = new PIXI.Sprite(PIXI.Texture.from('vignette'));
        this.backgroundContainer.addChild(vignette)
        vignette.width = config.width;
        vignette.height = config.height;

        let goodboy = new PIXI.Sprite(PIXI.Texture.from('goodboy'));
        this.backgroundContainer.addChild(goodboy)
        goodboy.anchor.set(0.5)
        goodboy.scale.set(config.width / goodboy.width * 0.12)
        goodboy.x = config.width / 2;
        goodboy.y = goodboy.height;
        // bigBlur.blendMode = PIXI.BLEND_MODES.ADD
        this.timeScale = 1;



        this.startPopUp = new StartPopUp('init', this);
        this.startPopUp.onConfirm.add(() =>
        {
            this.toGame()
        });

        this.startPopUp.onCatsRedirect.add(() =>
        {
            this.showPopUp('gameover')
        });

        this.GameOverPopUp = new GameOverPopUp('gameover', this);
        this.GameOverPopUp.onConfirm.add(() =>
        {
            // this.toStart()
            this.toGame()
        });

        this.GameOverPopUp.onInitRedirect.add(() =>
        {
            this.showPopUp('init')
        });

        this.popUpContainer = new PIXI.Container();
        this.addChild(this.popUpContainer);
        this.popUpList = [];
        this.popUpList.push(this.startPopUp);
        this.popUpList.push(this.GameOverPopUp);


        this.currentPopUp = null;
        this.prevPopUp = null;

        // this.showPopUp('gameover')
        this.showPopUp('init')

    }
    showPopUp(label, param = null)
    {
        if (this.currentPopUp && this.currentPopUp.label != label)
        {
            // this.currentPopUp.hide();
            this.prevPopUp = this.currentPopUp;
        }
        for (var i = 0; i < this.popUpList.length; i++)
        {
            if (this.popUpList[i].label == label)
            {
                this.popUpList[i].show(param);
                this.popUpContainer.addChild(this.popUpList[i]);
                this.currentPopUp = this.popUpList[i];
            }
        }
    }
    change(screenLabel, param)
    {
        super.change(screenLabel, param);
    }
    update(delta)
    {
        super.update(delta * this.timeScale);

        if(this.currentPopUp){
            this.currentPopUp.update(delta * this.timeScale)
        }
        if (this.prevPopUp && this.prevPopUp.toRemove && this.prevPopUp.parent)
        {
            this.prevPopUp.parent.removeChild(this.prevPopUp);
            this.prevPopUp = null;
        }
    }

    toGame()
    {
        if (this.currentScreen.label == 'GameScreen')
        {
            this.currentScreen.resetGame();
        }
    }
    toLoad()
    {}
    toStart()
    {
        this.showPopUp('init')
    }

    shake(force = 1, steps = 4, time = 0.25)
    {
        let timelinePosition = new TimelineLite();
        let positionForce = (force * 50);
        let spliterForce = (force * 20);
        let speed = time / steps;
        for (var i = steps; i >= 0; i--)
        {
            timelinePosition.append(TweenLite.to(this.screensContainer, speed,
            {
                x: Math.random() * positionForce - positionForce / 2,
                y: Math.random() * positionForce - positionForce / 2,
                ease: "easeNoneLinear"
            }));
        };

        timelinePosition.append(TweenLite.to(this.screensContainer, speed,
        {
            x: 0,
            y: 0,
            ease: "easeeaseNoneLinear"
        }));
    }
}