<?xml version="1.0" encoding="UTF-8"?>
<tileset name="HubGuides" tilewidth="155" tileheight="158" tilecount="2" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="155" height="121" source="aries.png"/>
 </tile>
 <tile id="1">
  <image width="94" height="158" source="virgo.png"/>
 </tile>
</tileset>
