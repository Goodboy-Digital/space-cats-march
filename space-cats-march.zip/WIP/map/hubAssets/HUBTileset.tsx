<?xml version="1.0" encoding="UTF-8"?>
<tileset name="HUBTileset" tilewidth="64" tileheight="64" tilecount="2" columns="0">
 <tileoffset x="-32" y="32"/>
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <properties>
   <property name="type" value="MainStar"/>
  </properties>
  <image width="64" height="64" source="mainstar.png"/>
 </tile>
 <tile id="1">
  <properties>
   <property name="type" value="MidStar"/>
  </properties>
  <image width="64" height="64" source="smalstar.png"/>
 </tile>
</tileset>
